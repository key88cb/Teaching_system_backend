package com.example.onlinetestingbackend.dto;

public class QueryPaperQuestionRequestDto {
    private Integer courseId;
    private Integer paperId;

    public Integer getCourseId() {
        return courseId;
    }

    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    public Integer getPaperId() {
        return paperId;
    }

    public void setPaperId(Integer paperId) {
        this.paperId = paperId;
    }
}
